public class FuncionarioTempoParcial extends Funcionario{

  public FuncionarioTempoParcial(String nome, float salario){
    super(nome, salario);
  }

}