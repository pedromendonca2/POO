public class FuncionarioTempoIntegral extends Funcionario{
  
  public FuncionarioTempoIntegral(String nome, float salario){
    super(nome, salario);
  }
  
}